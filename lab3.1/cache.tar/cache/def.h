#ifndef CACHE_DEF_H_
#define CACHE_DEF_H_

#define TRUE 1
#define FALSE 0

#define WRITE_BACK
//#define WRITE_THROUGH
#define WRITE_ALLOCATION
//#define WRITE_NOALLOCATION

#endif //CACHE_DEF_H_
